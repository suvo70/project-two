import React from "react";
import { useHistory } from "react-router-dom";
import "./About.css";

function About({ match }) {
  const history = useHistory();
  console.log("match value:", { match });
  return (
    <div className="background">
      <h1>About Page</h1>
      <h1>Hallo! {match.params.myName}</h1>
      <button
        className="btn-home"
        onClick={() => {
          history.push("/home_page");
        }}
      >
        Home
      </button>
    </div>
  );
}

export default About;
