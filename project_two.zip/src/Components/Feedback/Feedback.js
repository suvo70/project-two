import React from "react";
import "./FeedbackStyle.css";
import { useFormik } from "formik";
import axios from "axios";

const ValidateValues = (formValue) => {
  const errors = {};

  const reg_exp = /^[a-zA-Z ]*$/;
  // const reg_exp = /^[a-z]([-']?[a-z]+)*( [a-z]([-']?[a-z]+)*)+$/;

  if (!formValue.fullname) {
    errors.fullname = "Please enter the fullname";
  } else if (!reg_exp.test(formValue.fullname)) {
    errors.fullname = "Please enter proper formate for name";
  } else if (formValue.fullname.length < 5) {
    errors.fullname = "maxlength 5";
  }
  if (!formValue.address) {
    errors.address = "Please enter your address properly";
  }
  if (!formValue.email) {
    errors.email = "Please enter a valid email id";
  }
  if (!formValue.phone) {
    errors.phone = "Please enter a valid phone number";
  }
  console.log(errors);
  return errors;
};

function Feedback() {
  const formik = useFormik({
    initialValues: {
      fullname: "",
      address: "",
      phone: "",
      email: "",
    },

    validate: ValidateValues,

    onSubmit: (values) => {
      console.log("Submitted Values: ", values);
      const process = values;
      axios
        .post("https://jsonplaceholder.typicode.com/users", process)

        .then((result) => {
          console.log(result);
        })
        .catch((errorProcess) => {
          console.log(errorProcess);
        });
    },
  });
  return (
    <div className="font_fstyle">
      <h1>Feedback Form</h1>
      <form onSubmit={formik.handleSubmit}>
        <label className="label_fstyle full">Full name</label>
        <input
          type="text"
          placeholder="ABC"
          name="fullname"
          value={formik.values.fullname}
          onChange={formik.handleChange}
          className="input_fstyle"
        />
        <br />
        {formik.errors.fullname ? <span>{formik.errors.fullname}</span> : null}
        <br />
        <label className="label_fstyle">Address</label>
        <input
          type="message"
          placeholder="Address"
          name="address"
          value={formik.values.address}
          onChange={formik.handleChange}
          className="input_fstyle"
        />
        <br />
        {formik.errors.address ? <span>{formik.errors.address}</span> : null}
        <br />
        <label className="label_fstyle text">Phone Number</label>
        <input
          type="number"
          placeholder="0123456789"
          name="phone"
          value={formik.values.phone}
          onChange={formik.handleChange}
          className="input_fstyle "
        />
        <br />
        {formik.errors.phone ? <span>{formik.errors.phone}</span> : null}
        <br />
        <label className="label_fstyle">Email Id</label>
        <input
          type="text"
          placeholder="abc@gmail.com"
          name="email"
          value={formik.values.email}
          onChange={formik.handleChange}
          className="input_fstyle"
        />
        <br />
        {formik.errors.email ? <span>{formik.errors.email}</span> : null}
        <br />
        <button
          variant="primary"
          type="submit"
          disabled={!(formik.isValid && formik.dirty)}
          className="btn_fstyle"
        >
          Submit
        </button>
      </form>
    </div>
  );
}

export default Feedback;
