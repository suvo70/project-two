import React from "react";
import { useHistory } from "react-router-dom";

function Home() {
  const history1 = useHistory();
  return (
    <div>
      <h1>Home Page</h1>
      <button onClick={() => history1.push("/home_page")}>Back</button>
    </div>
  );
}

export default Home;
