import "./App.css";
import RootRoute from "./Routing/RootRoute";
import "bootstrap/dist/css/bootstrap.min.css";

function App() {
  return (
    <div className="App">
      <RootRoute />
    </div>
  );
}

export default App;
