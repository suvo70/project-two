import React from "react";
import productData from "./Product.json";
import { Card } from "react-bootstrap";
import { Link } from "react-router-dom";

function ProductSubCatagory({ match }) {
  const subData = productData.Product.find(
    (data) => data.p_id === match.params.prodId
  );
  console.log("Sub Data: ", subData);
  return (
    <div
      style={{
        // display: "flex",
        width: "100%",
        height: "100vh",
        background: "linear-gradient(to top left, #28b487, #7dd56f)",
      }}
    >
      {subData.subCatagory.map((prodSub) => (
        <Card
          border="primary"
          style={{
            marginTop: "20px",
            padding: "5px",
            margin: "5px",
            border: "none",
            "background-color": "#fff",
            color: "#444",
            "border-radius": "10rem",
            cursor: "pointer",
          }}
        >
          <Link
            to={`/ProductDetails_page/${match.params.prodId}/${prodSub.s_id}`}
            key={prodSub.s_id}
          >
            <h1>{prodSub.company}</h1>
          </Link>
        </Card>
      ))}
    </div>
  );
}

export default ProductSubCatagory;
