import React from "react";
import productData from "./Product.json";
import { Link } from "react-router-dom";

function ProductCatagory() {
  return (
    <div
      style={{
        // display: "flex",
        width: "100%",
        height: "100vh",
        background: "linear-gradient(to top left, #28b487, #7dd56f)",
      }}
    >
      {productData.Product.map((value) => (
        <Link
          to={`/productSubCatagory/${value.p_id}`}
          key={value.p_id}
          style={{
            marginTop: "20px",
            padding: "5px",
            margin: "5px",
            border: "none",
            backgroundCcolor: "#fff",
            color: "#444",
            "border-radius": "10rem",
            cursor: "pointer",
          }}
        >
          <h1>{value.p_name}</h1>
        </Link>
      ))}
    </div>
  );
}

export default ProductCatagory;
