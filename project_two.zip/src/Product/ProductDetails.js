import React from "react";
import productData from "./Product.json";
import { Card } from "react-bootstrap";

function ProductDetails({ match }) {
  const prodData = productData.Product.find(
    (data) => data.p_id === match.params.prodId
  );
  const dlsData = prodData.subCatagory.find(
    (data) => data.s_id === match.params.subId
  );
  console.log(dlsData);
  return (
    <div
      style={{
        display: "flex",
        width: "100%",
        height: "100vh",
        background: "linear-gradient(to top left, #28b487, #7dd56f)",
      }}
    >
      {/* <div style={{ display: "flex" }}>
        <h1>Samsung Galaxcy M32 (8/128GB)</h1>
        <p>
          16.21 cm (6.4"), FHD+ 6GB RAM | 128GB ROM | Android 11 MediaTek Helio
          Octa Core G80 Processor R: 64MP + 8MP + 2MP + 2MP | F: 20MP 6000 mAh
          Lithium Ion Battery Geomagnetic Sensor | Fingerprint Sensor
        </p>
      </div> */}

      {dlsData.details.map((prodDetl) => (
        <Card
          border="primary"
          style={{
            width: "18rem",
            display: "flex",
            position: "relative",
            margin: "10px",
            backgroundColor: "none",
            textAlign: "centre",
            transform: "translate( 30%)",
          }}
          key={prodDetl.d_id}
        >
          <Card.Body>
            <Card.Img variant="top" src={prodDetl.s_img} />
            <Card.Title>{prodDetl.model_name}</Card.Title>
            <Card.Text>{prodDetl.price}</Card.Text>
            <Card.Text>{prodDetl.specification}</Card.Text>
          </Card.Body>
        </Card>
      ))}
    </div>
  );
}

export default ProductDetails;
