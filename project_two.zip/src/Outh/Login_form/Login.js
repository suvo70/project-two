import React, { useState } from "react";
import { useHistory } from "react-router-dom";
import "./LoginStyle.css";

function Login() {
  const validEmail = RegExp("^([a-z0-9.-]+)@([a-z]{5,12}).([a-z.]{2,20})$");
  const validPass = RegExp(
    "^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9])(?=.*[a-z]).{4,12}$"
  );

  const history = useHistory();
  const [inputState, setInputState] = useState({
    isError: {
      email: "",
      password: "",
    },
  });

  const handleChange = (event) => {
    event.persist();
    //console.log("handle Change: ", event);
    let { name, value } = event.target;
    let isErr = { ...inputState.isError };
    switch (name) {
      case "email":
        isErr.email = validEmail.test(value) ? "" : "Wrong Pattern";
        break;
      case "password":
        isErr.password = validPass.test(value) ? "" : "Wrong Pattern";
        break;
      default:
        break;
    }
    setInputState({ ...inputState, [name]: value, isError: isErr });
    console.log("Input state: ", inputState);
  };

  const submitHandler = (event) => {
    event.preventDefault();
    console.log("after Submit: ", inputState);
  };

  return (
    <div className="font">
      <h1>Log in</h1>
      <form onSubmit={submitHandler}>
        <label style={{ fontSize: "30px" }}>Email id</label>
        <input
          type="text"
          placeholder="abc@gmail.com"
          name="email"
          onChange={handleChange}
          className="main"
        />
        {inputState.isError.email.length > 0 && (
          <span>{inputState.isError.email}</span>
        )}
        <br />
        <label style={{ fontSize: "30px", marginRight: "20px" }}>
          Password
        </label>
        <input
          type="password"
          placeholder="********"
          name="password"
          onChange={handleChange}
          className="main main_pass"
        />
        {inputState.isError.password.length > 0 && (
          <span>{inputState.isError.password}</span>
        )}
        <br />
        <button variant="promary" type="submit" className="btn_submit">
          Submit
        </button>
        <h1 className="control">
          Would you like to{" "}
          <button
            onClick={() => {
              history.push("/Registration_page");
            }}
            className="btn_signin"
          >
            Register
          </button>
        </h1>
      </form>
    </div>
  );
}

export default Login;
