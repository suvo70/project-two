import React, { useState } from "react";
import { Container, Row, Col } from "react-bootstrap";
import "./RegFormStyle.css";
import axios from "axios";

function RegForm() {
  const validateEmail = RegExp("^([a-z0-9.-]+)@([a-z]{5,12}).([a-z.]{2,20})$");
  const validatePassword = RegExp(
    "^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9])(?=.*[a-z]).{4,12}$"
  );
  // const validatePhone = RegExp("^(?([0-9]{3}))?[-]?([0-9]{3})[-]?([0-9]{4})$");
  const validatePhone = RegExp("[7-9]{1}[0-9]{9}");
  const [inputState, setInputState] = useState({
    isError: {
      firstname: "",
      lastname: "",
      phone: "",
      email: "",
      password: "",
    },
  });

  const handleChange = (event) => {
    event.persist();
    //console.log("Handlechange: ", event);
    let { name, value } = event.target;
    let isErr = { ...inputState.isError };
    switch (name) {
      case "firstname":
        isErr.firstname =
          value.length < 4 ? "Atleast 4 characters required" : "";
        break;
      case "lastname":
        isErr.lastname =
          value.length < 4 ? "Atleast 4 characters required" : "";
        break;
      case "phone":
        isErr.phone =
          // value.length < 10
          //   ? "Atleast 10 characters required"
          //   : value.length > 10
          //   ? "Invalid Phone Number"
          //   : "";
          validatePhone.test(value)
            ? value.length > 10
              ? "Invalid Phone Number"
              : "Atleast 10 number required"
            : "Invalid Phone Number";
        break;
      case "email":
        //isErr.email = value.length < 4 ? "Atleast 4 characters required" : "";
        isErr.email = validateEmail.test(value) ? "" : "Wrong Pattern";
        break;
      case "password":
        isErr.password =
          // value.length < 4 ? "Atleast 4 characters required" : "";
          validatePassword.test(value) ? "" : "Wrong Pattern";
        break;
      default:
        break;
    }
    setInputState({ ...inputState, [name]: value, isError: isErr });
    console.log(inputState);

    // part 4
    // setInputState({ ...inputState, [name]: value });
    // console.log("Input State: ", inputState);
  };

  const submitHandler = (event) => {
    event.preventDefault();
    console.log("After submit: ", inputState);
    const user = inputState;

    axios
      .post("https://jsonplaceholder.typicode.com/users", user)

      .then((res) => {
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      });
  };
  return (
    <div className="font_style">
      <h1>Registration page</h1>
      <form onSubmit={submitHandler}>
        <Container>
          <Row>
            <Col>
              <label className="label_style">First name</label>
              <input
                type="text"
                placeholder="ABC"
                name="firstname"
                onChange={handleChange}
                className="input_style"
              />
              {inputState.isError.firstname.length > 0 && (
                <span>
                  <br />
                  {inputState.isError.firstname}
                </span>
              )}
            </Col>
            <Col>
              <label className="label_style">Last name</label>

              <input
                type="text"
                placeholder="abc"
                name="lastname"
                onChange={handleChange}
                required
                className="input_style"
              />
              {inputState.isError.lastname.length > 0 && (
                <span>
                  <br />
                  {inputState.isError.lastname}
                </span>
              )}
            </Col>
          </Row>
          <Row>
            <Col>
              <label className="label_style phone">Phone Number</label>

              <input
                type="number"
                placeholder="0123456789"
                name="phone"
                onChange={handleChange}
                className="input_style"
              />
              {inputState.isError.phone.length > 0 && (
                <span className="show">
                  <br />
                  {inputState.isError.phone}
                </span>
              )}
            </Col>
          </Row>
          <Row>
            <Col>
              {" "}
              <label className="label_style email">Email Id</label>
              <input
                type="email"
                placeholder="abc@email.com"
                name="email"
                onChange={handleChange}
                className="input_style"
              />
              {inputState.isError.email.length > 0 && (
                <span>
                  <br />
                  {inputState.isError.email}
                </span>
              )}
            </Col>
            <Col>
              {" "}
              <label className="label_style pass">Password</label>
              <input
                type="password"
                placeholder="password"
                name="password"
                onChange={handleChange}
                className="input_style"
              ></input>
              {inputState.isError.password.length > 0 && (
                <span>
                  <br />
                  {inputState.isError.password}
                </span>
              )}
            </Col>
          </Row>
          <Row>
            <Col>
              <button variant="promary" type="submit" className="btn_style">
                Submit
              </button>
            </Col>
          </Row>
        </Container>

        {/* <label className="label_style">First name</label>
        <input
          type="text"
          placeholder="ABC"
          name="firstname"
          onChange={handleChange}
          className="input_style"
        />
        {inputState.isError.firstname.length > 0 && (
          <span>
            <br />
            {inputState.isError.firstname}
          </span>
        )}
        <br />
        <label className="label_style">Last name</label>

        <input
          type="text"
          placeholder="abc"
          name="lastname"
          onChange={handleChange}
          required
          className="input_style"
        />
        {inputState.isError.lastname.length > 0 && (
          <span>
            <br />
            {inputState.isError.lastname}
          </span>
        )}
        <br />
        <label className="label_style phone">Phone Number</label>

        <input
          type="number"
          placeholder="0123456789"
          name="phone"
          onChange={handleChange}
          className="input_style"
        />
        {inputState.isError.phone.length > 0 && (
          <span>
            <br />
            {inputState.isError.phone}
          </span>
        )}
        <br />
        <label className="label_style email">Email Id</label>
        <input
          type="email"
          placeholder="abc@email.com"
          name="email"
          onChange={handleChange}
          className="input_style"
        />
        {inputState.isError.email.length > 0 && (
          <span>
            <br />
            {inputState.isError.email}
          </span>
        )}
        <br />
        <label className="label_style pass">Password</label>
        <input
          type="password"
          placeholder="password"
          name="password"
          onChange={handleChange}
          className="input_style"
        ></input>
        {inputState.isError.password.length > 0 && (
          <span>
            <br />
            {inputState.isError.password}
          </span>
        )}
        <br />
        <button variant="promary" type="submit" className="btn_style">
          Submit
        </button> */}
      </form>
    </div>
  );
}

export default RegForm;
