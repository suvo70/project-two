import React, { useState, useEffect } from "react";
import { Card, Button } from "react-bootstrap";
import { Link } from "react-router-dom";
import axios from "axios";
import "./ItemSubCatStyle.css";

function ItemSubCatagory({ match }) {
  const [itemState, setItemState] = useState({
    itemData: [],
  });
  const catName = match.params.subItem;
  console.log("CatName: ", catName);
  useEffect(() => {
    axios
      .get(`https://fakestoreapi.com/products/category/${catName}`)
      .then((res) => {
        console.log("SubCat: ", res);
        setItemState({ itemData: res.data });
      })
      .catch(
        (err) => {
          console.log(err);
        },
        [setItemState]
      );
  }, []);
  return (
    <div className="box-s">
      {itemState.itemData.map((itemSub) => (
        <Card className="card-st">
          <Card.Img variant="top" src={itemSub.image} className="img-control" />
          <Card.Body>
            <Card.Title>{itemSub.title}</Card.Title>
            <div className="d-grid gap-2">
              <Button
                variant="outline-warning"
                size="lg"
                className="btn-position"
              >
                <Link to={`/ItemDetails_page/${itemSub.id}`} key={itemSub.id}>
                  <h1 className="btn-tx">Details</h1>
                </Link>
              </Button>
            </div>
          </Card.Body>
        </Card>
      ))}
    </div>
  );
}

export default ItemSubCatagory;
