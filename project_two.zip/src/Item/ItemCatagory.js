import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import axios from "axios";
import { Card, Row, Col } from "react-bootstrap";
import "./ItemCatStyle.css";

function ItemCatagory() {
  const [itemState, setItemState] = useState({
    itemData: [],
  });
  //useEffect=componentDidMount + componentDidUpdate
  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products")
      .then((res) => {
        console.log("poducts: ", res);
        setItemState({ itemData: res.data });
      })
      .catch((err1) => {
        console.log(err1);
      });
  }, [setItemState]);
  return (
    <div className="back-ground">
      {itemState.itemData.map((items) => (
        <Row xs={1} md={2} className="g-4 control">
          {Array.from({ length: 1 }).map((_, idx) => (
            <Col className="position">
              <Card className="redi">
                <Card.Img
                  variant="left"
                  src={items.image}
                  className="img-siz"
                />
                <Card.Body>
                  <Card.Title>
                    <Link
                      key={items.id}
                      to={`/ItemsSubCategory_page/${items.category}`}
                      style={{
                        color: "#000",
                      }}
                    >
                      <h1 className="text-format">{items.category}</h1>
                    </Link>
                  </Card.Title>
                </Card.Body>
              </Card>
            </Col>
          ))}
        </Row>
      ))}
    </div>
  );
}

export default ItemCatagory;
