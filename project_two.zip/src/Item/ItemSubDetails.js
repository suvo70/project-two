import React from "react";

function ProductSubDetails() {
  return <div></div>;
}

export default ProductSubDetails;
