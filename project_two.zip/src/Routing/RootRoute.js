import React, { lazy, Suspense } from "react";
import { Route, Switch, BrowserRouter as Router } from "react-router-dom";
import Home from "../Components/Home/Home";
//import Feedback from "../Components/Feedback/Feedback";
import About from "../Components/About/About";
import Header from "../LayOut/Header/Header";
import ProductCatagory from "../Product/ProductCatagory";
import ProductSubCatagory from "../Product/ProductSubCatagory";
import ProductDetails from "../Product/ProductDetails";
import ItemCatagory from "../Item/ItemCatagory";
import RegForm from "../Outh/Registration/RegForm";
import Login from "../Outh/Login_form/Login";
import ItemSubCatagory from "../Item/ItemSubCatagory";
import ItemDetails from "../Item/ItemDetails";
const Feedback = lazy(() => import("../Components/Feedback/Feedback"));

function RootRoute() {
  return (
    <Router>
      <Header />
      <Switch>
        <Route exact path="/" component={Home}></Route>
        <Route path="/about/:myName" component={About}></Route>
        <Route path="/productCatagory" component={ProductCatagory}></Route>
        <Route
          path="/productSubCatagory/:prodId"
          component={ProductSubCatagory}
        ></Route>
        <Route
          path="/ProductDetails_page/:prodId/:subId"
          component={ProductDetails}
        />
        <Route
          path="/feedback_page"
          render={() => (
            <Suspense fallback={<h1>Loading...</h1>}>
              <Feedback />
            </Suspense>
          )}
        />
        <Route path="/ItemsCategory_page" component={ItemCatagory} />
        <Route
          path="/ItemsSubCategory_page/:subItem"
          component={ItemSubCatagory}
        />
        <Route path="/ItemDetails_page/:subId" component={ItemDetails} />
        <Route path="/Registration_page" component={RegForm} />
        <Route path="/Login_page" component={Login} />
        <Route render={() => <h1>404: Page not found!!!</h1>}></Route>
      </Switch>
    </Router>
  );
}

export default RootRoute;
